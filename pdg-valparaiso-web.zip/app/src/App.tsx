import { HashRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import DiputadoOlivares from './pages/DiputadoOlivares';
import DiputadoValenzuela from './pages/DiputadoValenzuela';
import Transparencia from './pages/Transparencia';
import Formacion from './pages/Formacion';
import Voluntarios from './pages/Voluntarios';
import Comunidad from './pages/Comunidad';
import './App.css';

function App() {
  return (
    <HashRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/olivares" element={<DiputadoOlivares />} />
          <Route path="/valenzuela" element={<DiputadoValenzuela />} />
          <Route path="/transparencia" element={<Transparencia />} />
          <Route path="/formacion" element={<Formacion />} />
          <Route path="/voluntarios" element={<Voluntarios />} />
          <Route path="/comunidad" element={<Comunidad />} />
        </Route>
      </Routes>
    </HashRouter>
  );
}

export default App;
