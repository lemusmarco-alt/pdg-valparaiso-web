import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MessageSquare, AlertCircle } from 'lucide-react';

const tabs = [
  { id: 'general', label: 'General' },
  { id: 'd6', label: 'Distrito 6 (Olivares)' },
  { id: 'd7', label: 'Distrito 7 (Valenzuela)' },
  { id: 'trans', label: 'Transparencia' },
];

const Comunidad = () => {
  const [activeTab, setActiveTab] = useState('general');

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-[#0a1628] via-[#0f1f3d] to-[#162a50] py-16 lg:py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 flex items-center justify-center mx-auto mb-4">
            <MessageSquare className="w-8 h-8 text-amber-400" />
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-4">
            Comunidad <span className="text-amber-400">PDG</span>
          </h1>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Comparte tu opinión, propón ideas y debate con otros militantes y simpatizantes sobre el futuro de Valparaíso.
          </p>
        </div>
      </section>

      {/* Forum */}
      <section className="py-12 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border border-slate-200">
            <CardContent className="p-6">
              {/* Tabs */}
              <div className="flex flex-wrap gap-2 mb-6">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                      activeTab === tab.id
                        ? 'bg-[#0f1f3d] text-white shadow-md'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Login prompt */}
              <div className="bg-slate-50 rounded-2xl p-8 text-center mb-8 border border-slate-200">
                <AlertCircle className="w-10 h-10 text-amber-600 mx-auto mb-3" />
                <p className="text-slate-600 mb-4">Inicia sesión para participar en la conversación.</p>
                <Button className="bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-bold">
                  Ingresar
                </Button>
              </div>

              {/* Empty state */}
              <div className="text-center py-12 border-2 border-dashed border-slate-200 rounded-2xl">
                <MessageSquare className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <p className="text-slate-500">Aún no hay comentarios en esta sección. ¡Sé el primero!</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Comunidad;
