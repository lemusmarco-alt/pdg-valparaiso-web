import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { GraduationCap, Calendar, Clock, MapPin, Users, ArrowRight, Send } from 'lucide-react';

const comunas = [
  'Valparaíso', 'Viña del Mar', 'Quilpué', 'Villa Alemana', 'Concón', 'Quillota',
  'San Antonio', 'Los Andes', 'San Felipe', 'La Calera', 'Limache', 'Olmué', 'Otra'
];

const Formacion = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="/formacion.jpg" alt="Formación Política" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a1628]/95 via-[#0a1628]/85 to-[#0a1628]/70" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge variant="outline" className="mb-4 border-amber-500/50 text-amber-400 bg-amber-500/10 px-4 py-1 text-xs font-semibold">
            <GraduationCap className="w-3 h-3 mr-1" />
            ESCUELA DE FORMACIÓN PDG
          </Badge>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white mb-4">
            Formación <span className="text-amber-400">Política</span>
          </h1>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Capacítate con nosotros. Participa en nuestras clases y talleres de formación política para fortalecer tu liderazgo y compromiso con la comunidad.
          </p>
        </div>
      </section>

      {/* Evento */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-2">Próximo Evento</p>
            <h2 className="text-3xl font-extrabold text-[#0f1f3d]">Próxima Clase de Formación</h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Info evento */}
            <Card className="border border-slate-200 overflow-hidden hover:shadow-lg transition-all">
              <div className="relative h-56">
                <img src="/formacion.jpg" alt="Taller" className="w-full h-full object-cover" />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-amber-500 text-[#0f1f3d] font-bold px-3 py-1">INSCRIPCIONES ABIERTAS</Badge>
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-[#0f1f3d] mb-3">
                  Taller de Liderazgo Político y Gestión Comunal
                </h3>
                <p className="text-slate-500 mb-6 leading-relaxed">
                  Aprende las herramientas fundamentales para ejercer un liderazgo efectivo en tu comunidad. Este taller abordará estrategias de gestión comunal, comunicación política y organización territorial.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-amber-600" />
                    <span className="text-slate-600">Sábado 24 de Mayo, 2026</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="w-4 h-4 text-amber-600" />
                    <span className="text-slate-600">10:00 - 13:00 hrs</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-amber-600" />
                    <span className="text-slate-600">Sede Regional PDG, Valparaíso</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-amber-600" />
                    <span className="text-slate-600">30 participantes</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Formulario */}
            <Card className="border border-slate-200">
              <CardContent className="p-6">
                {submitted ? (
                  <div className="text-center py-12">
                    <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Send className="w-8 h-8 text-emerald-600" />
                    </div>
                    <h3 className="text-2xl font-bold text-[#0f1f3d] mb-2">¡Inscripción enviada!</h3>
                    <p className="text-slate-500">Te contactaremos pronto con más detalles sobre el taller.</p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 rounded-xl bg-[#0f1f3d] flex items-center justify-center">
                        <GraduationCap className="w-5 h-5 text-amber-400" />
                      </div>
                      <div>
                        <h3 className="font-bold text-[#0f1f3d]">Formulario de Inscripción</h3>
                        <p className="text-sm text-slate-500">Completa tus datos para reservar tu cupo</p>
                      </div>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="nombre" className="text-sm font-medium">Nombre</Label>
                          <Input id="nombre" placeholder="Tu nombre" className="mt-1" required />
                        </div>
                        <div>
                          <Label htmlFor="apellido" className="text-sm font-medium">Apellido</Label>
                          <Input id="apellido" placeholder="Tu apellido" className="mt-1" required />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="correo" className="text-sm font-medium">Correo Electrónico</Label>
                        <Input id="correo" type="email" placeholder="correo@ejemplo.cl" className="mt-1" required />
                      </div>
                      <div>
                        <Label htmlFor="telefono" className="text-sm font-medium">Teléfono</Label>
                        <Input id="telefono" placeholder="+56 9 1234 5678" className="mt-1" />
                      </div>
                      <div>
                        <Label htmlFor="comuna" className="text-sm font-medium">Comuna</Label>
                        <Select>
                          <SelectTrigger className="mt-1">
                            <SelectValue placeholder="Selecciona tu comuna" />
                          </SelectTrigger>
                          <SelectContent>
                            {comunas.map(c => <SelectItem key={c} value={c.toLowerCase()}>{c}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="motivo" className="text-sm font-medium">¿Por qué deseas participar?</Label>
                        <textarea
                          id="motivo"
                          rows={3}
                          className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                        />
                      </div>
                      <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-bold">
                        Inscribirme al Taller
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                      <p className="text-xs text-slate-400 text-center">
                        Al inscribirte aceptas recibir información sobre futuras actividades de formación del PDG.
                      </p>
                    </form>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Formacion;
