import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Heart, Send, ArrowRight } from 'lucide-react';

const comunas = [
  'Valparaíso', 'Viña del Mar', 'Concón', 'Quilpué', 'Villa Alemana', 'Casablanca',
  'San Antonio', 'Quillota', 'La Calera', 'Los Andes', 'San Felipe', 'La Ligua'
];

const areas = [
  'Campaña territorial (puerta a puerta)',
  'Redes sociales y comunicación',
  'Organización de eventos',
  'Atención ciudadana',
  'Formación política',
  'Logística y operaciones',
];

const Voluntarios = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-[#0a1628] via-[#0f1f3d] to-[#162a50] py-16 lg:py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/20 flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8 text-amber-400" />
          </div>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-4">
            Únete como <span className="text-amber-400">voluntario</span>
          </h1>
          <p className="text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            Tu tiempo, tus ideas y tu energía son el motor del cambio. Regístrate y te contactaremos pronto para sumarte al equipo de tu comuna.
          </p>
        </div>
      </section>

      {/* Formulario */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border border-slate-200 shadow-lg">
            <CardContent className="p-6 sm:p-8">
              {submitted ? (
                <div className="text-center py-12">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Send className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-[#0f1f3d] mb-2">¡Gracias por tu interés!</h2>
                  <p className="text-slate-500">Hemos recibido tu solicitud. Te contactaremos pronto.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="nombre" className="text-sm font-medium">Nombre completo <span className="text-red-500">*</span></Label>
                      <Input id="nombre" placeholder="Tu nombre y apellidos" className="mt-1" required />
                    </div>
                    <div>
                      <Label htmlFor="email" className="text-sm font-medium">Email <span className="text-red-500">*</span></Label>
                      <Input id="email" type="email" placeholder="tu@email.com" className="mt-1" required />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="telefono" className="text-sm font-medium">Teléfono</Label>
                      <Input id="telefono" placeholder="+56 9 1234 5678" className="mt-1" />
                    </div>
                    <div>
                      <Label htmlFor="edad" className="text-sm font-medium">Rango etario</Label>
                      <Select>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Selecciona" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="18-25">18-25</SelectItem>
                          <SelectItem value="26-35">26-35</SelectItem>
                          <SelectItem value="36-50">36-50</SelectItem>
                          <SelectItem value="51-65">51-65</SelectItem>
                          <SelectItem value="65+">65+</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="comuna" className="text-sm font-medium">Comuna <span className="text-red-500">*</span></Label>
                    <Select>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Selecciona tu comuna" />
                      </SelectTrigger>
                      <SelectContent>
                        {comunas.map(c => <SelectItem key={c} value={c.toLowerCase()}>{c}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Áreas de interés</Label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                      {areas.map(area => (
                        <div key={area} className="flex items-center space-x-2 p-2 rounded-lg border border-slate-200 hover:bg-slate-50">
                          <Checkbox id={area} />
                          <label htmlFor={area} className="text-sm text-slate-600 cursor-pointer">{area}</label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="disponibilidad" className="text-sm font-medium">Disponibilidad</Label>
                    <Select>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Selecciona" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dia">Lunes a viernes (días)</SelectItem>
                        <SelectItem value="tarde">Lunes a viernes (tardes)</SelectItem>
                        <SelectItem value="finde">Fines de semana</SelectItem>
                        <SelectItem value="flex">Flexible</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="mensaje" className="text-sm font-medium">Mensaje (opcional)</Label>
                    <textarea
                      id="mensaje"
                      rows={3}
                      placeholder="Cuéntanos por qué quieres ser voluntario..."
                      className="w-full mt-1 px-3 py-2 border border-slate-200 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                    />
                  </div>

                  <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-bold py-6 text-base">
                    Enviar inscripción
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>

                  <p className="text-xs text-slate-400 text-center">
                    Tus datos serán tratados con total confidencialidad y están integrados con nuestro sistema NationBuilder para gestión de la comunidad.
                  </p>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Voluntarios;
