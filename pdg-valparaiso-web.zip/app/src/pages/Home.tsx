import { Link } from 'react-router-dom';
import { useEffect, useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  ArrowRight, Users, TrendingUp,
  Sparkles, Handshake, Eye, ScrollText, ChevronRight
} from 'lucide-react';

/* ──── Counter Hook ──── */
const useCounter = (end: number, duration = 2000, startCounting = false) => {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!startCounting) return;
    let start = 0;
    const step = Math.max(1, Math.floor(end / (duration / 16)));
    const timer = setInterval(() => {
      start += step;
      if (start >= end) { start = end; clearInterval(timer); }
      setCount(start);
    }, 16);
    return () => clearInterval(timer);
  }, [end, duration, startCounting]);
  return count;
};

/* ──── Visibility Hook ──── */
const useVisible = () => {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) setVisible(true);
    }, { threshold: 0.2 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);
  return { ref, visible };
};

/* ──── AnimatedCounter Component ──── */
const AnimatedCounter = ({ end, suffix = '', label }: { end: number; suffix?: string; label: string }) => {
  const { ref, visible } = useVisible();
  const count = useCounter(end, 2000, visible);
  return (
    <div ref={ref} className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-6 text-center hover:bg-white/15 transition-all">
      <p className="text-4xl sm:text-5xl font-extrabold text-amber-400">{count.toLocaleString()}{suffix}</p>
      <p className="text-sm text-slate-300 mt-1 font-medium">{label}</p>
    </div>
  );
};

/* ──── Data ──── */
const directiva = [
  { initials: 'CQ', name: 'Cristian Quinteros', role: 'Presidente Regional', desc: 'Lidera la directiva regional del PDG en Valparaíso.', img: '/directiva-hombre.jpg' },
  { initials: 'FE', name: 'Flavio Espinoza', role: 'Vicepresidente Regional', desc: 'Acompaña la conducción estratégica del partido en la región.', img: '/directiva-mujer.jpg' },
  { initials: 'PA', name: 'Paula Alcaino', role: 'Tesorera Regional', desc: 'Encargada de las finanzas y rendición de cuentas regional.', img: '/directiva-mujer.jpg' },
  { initials: 'CD', name: 'Camila Doñas', role: 'Secretaria Regional', desc: 'Coordina la gestión documental y operativa del comité regional.', img: '/directiva-mujer.jpg' },
  { initials: 'CM', name: 'Carol Meyer', role: 'Coordinadora Regional', desc: 'Articula el trabajo territorial con las directivas comunales.', img: '/directiva-mujer.jpg' },
  { initials: 'EC', name: 'Eduardo Cueto', role: 'Secretario Ejecutivo', desc: 'Ejecuta los acuerdos del comité regional y enlaza con la militancia.', img: '/directiva-hombre.jpg' },
  { initials: 'CE', name: 'Claudio Espindola', role: 'Director Programático', desc: 'Dirige la construcción programática y política del PDG regional.', img: '/directiva-hombre.jpg' },
];

const comunasD6 = [
  { name: 'Valparaíso', coord: 'María Pérez', militantes: 1580, simpatizantes: 234 },
  { name: 'Viña del Mar', coord: 'Carlos Díaz', militantes: 1240, simpatizantes: 186 },
  { name: 'Quilpué', coord: 'Ana Torres', militantes: 890, simpatizantes: 142 },
  { name: 'Villa Alemana', coord: 'Ana Torres Velasco', militantes: 720, simpatizantes: 118 },
  { name: 'Quillota', coord: 'Diego Navarro Pinto', militantes: 670, simpatizantes: 105 },
  { name: 'Los Andes', coord: 'Miguel Campos Reyes', militantes: 560, simpatizantes: 89 },
  { name: 'San Felipe', coord: 'Paula Escobar Ramos', militantes: 490, simpatizantes: 78 },
];

const comunasD7 = [
  { name: 'Concón', coord: 'Patricia Rojas Henríquez', militantes: 450, simpatizantes: 71 },
  { name: 'Casablanca', coord: 'Luis Fuentes Aravena', militantes: 420, simpatizantes: 68 },
  { name: 'La Calera', coord: 'Soledad Vargas Mena', militantes: 380, simpatizantes: 62 },
  { name: 'San Antonio', coord: 'Fernando Alarcón Lobos', militantes: 310, simpatizantes: 48 },
  { name: 'La Ligua', coord: 'Roberto Méndez', militantes: 280, simpatizantes: 42 },
];

const hitos = [
  { month: 'ago 2026', status: 'próximo', title: 'Meta 10.000 voluntarios', desc: 'Alcanzar 10.000 voluntarios activos antes de las elecciones.' },
  { month: 'jun 2026', status: 'próximo', title: 'Congreso Regional de la Juventud PDG', desc: 'Encuentro anual que reunirá a jóvenes líderes de toda la región.' },
  { month: 'may 2026', status: 'en progreso', title: 'Campaña Puerta a Puerta', desc: 'Inicio de la campaña territorial en 12 comunas estratégicas de la región.' },
  { month: 'abr 2026', status: 'completado', title: 'Plan Regional de Vivienda', desc: 'Presentación del plan de vivienda digna y asequible para Valparaíso.' },
];

/* ──── Home Page ──── */
const Home = () => {
  return (
    <div>
      {/* ========== HERO ========== */}
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src="/hero-valparaiso.jpg" alt="Valparaíso" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0a1628]/95 via-[#0a1628]/80 to-[#0a1628]/60" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a1628] via-transparent to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
          <div className="max-w-2xl">
            <Badge variant="outline" className="mb-6 border-amber-500/50 text-amber-400 bg-amber-500/10 backdrop-blur-sm px-4 py-1.5 text-xs font-semibold tracking-wide">
              <Sparkles className="w-3 h-3 mr-1.5" />
              REGIONAL VALPARAÍSO · ELECCIONES 2026
            </Badge>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6">
              Construyendo la{' '}
              <span className="text-amber-400">Región de Valparaíso</span>,
              comuna por comuna
            </h1>

            <p className="text-lg sm:text-xl text-slate-300 mb-8 leading-relaxed max-w-xl">
              Somos el PDG Regional. Transparencia en tiempo real, una red de voluntarios activa en toda la región y dos diputados comprometidos con el cambio.
            </p>

            <div className="flex flex-wrap gap-3 mb-10">
              <Link to="/voluntarios">
                <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-bold text-base shadow-lg hover:shadow-xl transition-all">
                  Únete como voluntario
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to="/transparencia">
                <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 font-semibold text-base backdrop-blur-sm">
                  Ver transparencia
                  <ChevronRight className="w-5 h-5 ml-1" />
                </Button>
              </Link>
            </div>

            {/* Social follow */}
            <div className="flex items-center gap-3">
              <span className="text-sm text-slate-400 font-medium">SÍGUENOS:</span>
              <div className="flex gap-2">
                {['instagram', 'youtube', 'twitter', 'facebook'].map((social) => (
                  <a
                    key={social}
                    href={`https://${social}.com/pdgchile`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-9 h-9 rounded-full bg-white/10 hover:bg-amber-500 hover:text-[#0f1f3d] flex items-center justify-center transition-all text-slate-300"
                  >
                    {social === 'instagram' && <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>}
                    {social === 'youtube' && <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>}
                    {social === 'twitter' && <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>}
                    {social === 'facebook' && <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>}
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 right-8 z-10 hidden md:flex items-center gap-2 text-slate-400 animate-bounce">
          <span className="text-sm">Desliza para conocer más</span>
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7" /></svg>
        </div>
      </section>

      {/* ========== STATS ========== */}
      <section className="bg-[#0a1628] py-16 relative -mt-1">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <AnimatedCounter end={0} label="Militantes" />
            <AnimatedCounter end={0} label="Simpatizantes" />
            <AnimatedCounter end={0} label="Comunas activas" />
            <AnimatedCounter end={0} label="Hitos logrados" />
          </div>
        </div>
      </section>

      {/* ========== VISION ========== */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-3">Nuestra Visión</p>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0f1f3d] mb-6">
            Un proyecto <span className="text-amber-500">humanista</span> para Valparaíso
          </h2>
          <p className="text-slate-600 text-lg max-w-3xl mx-auto leading-relaxed mb-12">
            El Partido de la Gente es una organización política independiente orientada a promover y defender la democracia y los derechos humanos. El fin de la sociedad es el desarrollo integral y pleno de las personas.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { icon: Eye, title: 'Transparencia', desc: 'Rendición de cuentas pública y acceso a la información en tiempo real.' },
              { icon: Users, title: 'Comunidad', desc: 'Construcción colectiva con participación ciudadana activa en cada comuna.' },
              { icon: Handshake, title: 'Compromiso', desc: 'Diputados y directiva comprometidos con el cambio real de la región.' },
            ].map(({ icon: Icon, title, desc }) => (
              <Card key={title} className="border border-slate-200 hover:border-amber-300 hover:shadow-lg transition-all group bg-white">
                <CardContent className="p-8 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-[#0f1f3d] flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-500 transition-colors">
                    <Icon className="w-7 h-7 text-amber-400 group-hover:text-[#0f1f3d] transition-colors" />
                  </div>
                  <h3 className="font-bold text-[#0f1f3d] text-lg mb-2">{title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">{desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ========== DIRECTIVA ========== */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-3">Directiva Regional</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0f1f3d]">
              El equipo que lidera la Región
            </h2>
            <p className="text-slate-500 mt-3 max-w-2xl mx-auto">
              Líderes comprometidos con los valores del PDG, el desarrollo regional y la participación ciudadana.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {directiva.map((person) => (
              <Card key={person.name} className="border border-slate-200 hover:shadow-lg transition-all group overflow-hidden">
                <CardContent className="p-6 flex gap-4 items-start">
                  {person.img ? (
                    <div className="w-14 h-14 rounded-full bg-slate-200 flex-shrink-0 overflow-hidden">
                      <img src={person.img} alt={person.name} className="w-full h-full object-cover" />
                    </div>
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-[#0f1f3d] flex items-center justify-center flex-shrink-0">
                      <span className="text-white font-bold text-sm">{person.initials}</span>
                    </div>
                  )}
                  <div className="min-w-0">
                    <h3 className="font-bold text-[#0f1f3d] group-hover:text-amber-600 transition-colors truncate">{person.name}</h3>
                    <p className="text-amber-600 text-xs font-semibold uppercase tracking-wide mb-1">{person.role}</p>
                    <p className="text-slate-500 text-sm leading-relaxed">{person.desc}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* ========== DIPUTADOS ========== */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-3">Nuestros Diputados</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0f1f3d]">
              Representando a la Región de Valparaíso en el Congreso
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Diputado Olivares */}
            <Card className="overflow-hidden border border-slate-200 hover:shadow-xl transition-all group">
              <div className="h-64 overflow-hidden relative">
                <img src="/olivares.jpg" alt="Javier Olivares" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute top-4 left-4 bg-amber-500 text-[#0f1f3d] px-3 py-1 rounded-full text-xs font-bold">
                  DISTRITO 6
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-[#0f1f3d] mb-1">Javier Ignacio Olivares Avendaño</h3>
                <p className="text-amber-600 text-sm font-medium mb-3">Diputado · Voz del Distrito 6</p>
                <p className="text-slate-500 text-sm leading-relaxed mb-4">
                  Periodista titulado de la UNIACC con trayectoria en medios nacionales e internacionales. Electo diputado con 32.334 votos.
                </p>
                <Link to="/olivares">
                  <Button variant="outline" className="border-[#0f1f3d] text-[#0f1f3d] hover:bg-[#0f1f3d] hover:text-white transition-all">
                    Ver perfil completo
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Diputado Valenzuela */}
            <Card className="overflow-hidden border border-slate-200 hover:shadow-xl transition-all group">
              <div className="h-64 overflow-hidden relative">
                <img src="/valenzuela.jpg" alt="Juan Marcelo Valenzuela" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute top-4 left-4 bg-amber-500 text-[#0f1f3d] px-3 py-1 rounded-full text-xs font-bold">
                  DISTRITO 7
                </div>
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-[#0f1f3d] mb-1">Juan Marcelo Valenzuela Henríquez</h3>
                <p className="text-amber-600 text-sm font-medium mb-3">Diputado · Voz del Distrito 7</p>
                <p className="text-slate-500 text-sm leading-relaxed mb-4">
                  Ingeniero Comercial, fundador de Granvalparaiso.cl y miembro fundador del PDG. Electo diputado con 26.410 votos.
                </p>
                <Link to="/valenzuela">
                  <Button variant="outline" className="border-[#0f1f3d] text-[#0f1f3d] hover:bg-[#0f1f3d] hover:text-white transition-all">
                    Ver perfil completo
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* ========== TERRITORIO ========== */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-3">Presencia Territorial</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0f1f3d]">Conectamos Buena Gente</h2>
          </div>

          <Tabs defaultValue="d6" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="bg-slate-200 p-1">
                <TabsTrigger value="d6" className="px-6 py-2 font-semibold data-[state=active]:bg-[#0f1f3d] data-[state=active]:text-white">Distrito 6</TabsTrigger>
                <TabsTrigger value="d7" className="px-6 py-2 font-semibold data-[state=active]:bg-[#0f1f3d] data-[state=active]:text-white">Distrito 7</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="d6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {comunasD6.map((comuna) => (
                  <Card key={comuna.name} className="border border-slate-200 hover:border-amber-300 hover:shadow-md transition-all">
                    <CardContent className="p-5">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-bold text-[#0f1f3d]">{comuna.name}</span>
                        <Badge variant="secondary" className="text-xs bg-amber-100 text-amber-700">D6</Badge>
                      </div>
                      <p className="text-xs text-slate-500 mb-2">Coord: {comuna.coord}</p>
                      <div className="flex gap-4 text-sm">
                        <span className="text-[#0f1f3d] font-semibold">{comuna.militantes.toLocaleString()}</span>
                        <span className="text-slate-400">{comuna.simpatizantes}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="d7">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                {comunasD7.map((comuna) => (
                  <Card key={comuna.name} className="border border-slate-200 hover:border-amber-300 hover:shadow-md transition-all">
                    <CardContent className="p-5">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-bold text-[#0f1f3d]">{comuna.name}</span>
                        <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700">D7</Badge>
                      </div>
                      <p className="text-xs text-slate-500 mb-2">Coord: {comuna.coord}</p>
                      <div className="flex gap-4 text-sm">
                        <span className="text-[#0f1f3d] font-semibold">{comuna.militantes.toLocaleString()}</span>
                        <span className="text-slate-400">{comuna.simpatizantes}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* ========== HITOS ========== */}
      <section className="py-20 bg-[#0a1628] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-10 gap-4">
            <div>
              <p className="text-amber-500 font-semibold text-sm uppercase tracking-wider mb-2">Hitos recientes</p>
              <h2 className="text-3xl font-extrabold text-white">Seguimiento en tiempo real</h2>
            </div>
            <Link to="/transparencia">
              <Button variant="outline" className="border-white/20 text-white hover:bg-white/10">
                Ver panel completo
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>

          <div className="space-y-4">
            {hitos.map((hito, i) => (
              <div key={i} className="flex flex-col sm:flex-row gap-4 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all">
                <div className="flex-shrink-0 w-20">
                  <p className="text-xs text-slate-400 font-medium">{hito.month}</p>
                  <Badge className={`mt-1 text-xs ${
                    hito.status === 'completado' ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30' :
                    hito.status === 'en progreso' ? 'bg-amber-500/20 text-amber-400 hover:bg-amber-500/30' :
                    'bg-blue-500/20 text-blue-400 hover:bg-blue-500/30'
                  }`}>
                    {hito.status}
                  </Badge>
                </div>
                <div className="flex-1">
                  <h3 className="text-white font-bold text-lg mb-1">{hito.title}</h3>
                  <p className="text-slate-400 text-sm">{hito.desc}</p>
                </div>
                <div className="flex-shrink-0">
                  {hito.status === 'completado' && <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center"><svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg></div>}
                  {hito.status === 'en progreso' && <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center"><svg className="w-4 h-4 text-amber-400 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg></div>}
                  {hito.status === 'próximo' && <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center"><svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg></div>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ========== DOCUMENTOS ========== */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-extrabold text-[#0f1f3d] mb-3">Documentación del Partido</h2>
          <p className="text-slate-500 mb-8">Pincha una viñeta para descargar automáticamente la documentación en formato PDF.</p>
          <div className="flex flex-wrap justify-center gap-4">
            {['Principios', 'Estatutos', 'Programa Electoral'].map((doc) => (
              <Button key={doc} variant="outline" size="lg" className="border-[#0f1f3d] text-[#0f1f3d] hover:bg-[#0f1f3d] hover:text-white px-8 py-6 text-base font-semibold shadow-sm hover:shadow-md transition-all">
                <ScrollText className="w-5 h-5 mr-2" />
                {doc.toUpperCase()}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* ========== CTA ========== */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-[#0f1f3d] to-[#162a50] rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl">
            <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-amber-500/5 rounded-full blur-2xl" />

            <div className="relative z-10">
              <TrendingUp className="w-12 h-12 text-amber-400 mx-auto mb-4" />
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white mb-4">
                Sé parte del cambio. <span className="text-amber-400">Sé PDG.</span>
              </h2>
              <p className="text-slate-300 text-lg mb-8 max-w-2xl mx-auto">
                Regístrate como voluntario, comenta tus propuestas o contáctanos directo por WhatsApp. Cada voz suma.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link to="/voluntarios">
                  <Button size="lg" className="bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-bold text-base shadow-lg">
                    Registrarme ahora
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to="/comunidad">
                  <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 font-semibold text-base">
                    Unirme a la comunidad
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
