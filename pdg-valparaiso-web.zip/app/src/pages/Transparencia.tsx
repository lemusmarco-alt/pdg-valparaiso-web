import { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, Heart, MapPin, Target, AlertCircle } from 'lucide-react';

const stats = [
  { icon: Users, value: '0', label: 'MILITANTES ACTIVOS', color: 'text-blue-400' },
  { icon: Heart, value: '0', label: 'SIMPATIZANTES', color: 'text-amber-400' },
  { icon: MapPin, value: '0', label: 'COMUNAS', color: 'text-emerald-400' },
  { icon: Target, value: '0', label: 'HITOS LOGRADOS', color: 'text-rose-400' },
];

const comunas = [
  { name: 'Valparaíso', d: 'D6', militantes: 1580, simp: 234, coord: 'María Pérez' },
  { name: 'Viña del Mar', d: 'D7', militantes: 1240, simp: 186, coord: 'Carlos Díaz' },
  { name: 'Quilpué', d: 'D6', militantes: 890, simp: 142, coord: 'Ana Torres' },
  { name: 'Villa Alemana', d: 'D6', militantes: 720, simp: 118, coord: 'Ana Torres Velasco' },
  { name: 'Concón', d: 'D7', militantes: 450, simp: 71, coord: 'Patricia Rojas' },
  { name: 'Quillota', d: 'D6', militantes: 670, simp: 105, coord: 'Diego Navarro' },
  { name: 'Casablanca', d: 'D7', militantes: 420, simp: 68, coord: 'Luis Fuentes' },
  { name: 'San Antonio', d: 'D7', militantes: 310, simp: 48, coord: 'Fernando Alarcón' },
  { name: 'Los Andes', d: 'D6', militantes: 560, simp: 89, coord: 'Miguel Campos' },
  { name: 'San Felipe', d: 'D6', militantes: 490, simp: 78, coord: 'Paula Escobar' },
  { name: 'La Calera', d: 'D6', militantes: 380, simp: 62, coord: 'Soledad Vargas' },
  { name: 'La Ligua', d: 'D6', militantes: 280, simp: 42, coord: 'Roberto Méndez' },
];

const Transparencia = () => {
  const [selectedComuna, setSelectedComuna] = useState<string | null>(null);
  const selected = comunas.find(c => c.name === selectedComuna);

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-[#0a1628] via-[#0f1f3d] to-[#162a50] py-16 lg:py-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <Badge variant="outline" className="mb-4 border-red-500/50 text-red-400 bg-red-500/10 px-4 py-1 text-xs font-semibold">
            <span className="w-2 h-2 rounded-full bg-red-500 mr-2 animate-pulse" />
            DATOS EN VIVO
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-white mb-4">
            Panel de <span className="text-amber-400">Transparencia</span>
          </h1>
          <p className="text-slate-300 text-lg max-w-3xl mx-auto leading-relaxed">
            Seguimiento público y en tiempo real de nuestra red de militantes, simpatizantes, comunas activas y hitos de campaña en toda la Región de Valparaíso.
          </p>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-white -mt-4">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {stats.map(({ icon: Icon, value, label, color }) => (
              <Card key={label} className="border border-slate-200 hover:shadow-lg transition-all">
                <CardContent className="p-6 text-center">
                  <Icon className={`w-8 h-8 mx-auto mb-3 ${color}`} />
                  <p className="text-4xl font-extrabold text-[#0f1f3d] mb-1">{value}</p>
                  <p className="text-xs text-slate-500 font-semibold tracking-wide">{label}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mapa Interactivo */}
      <section className="py-16 bg-slate-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10">
            <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-3">Mapa Interactivo</p>
            <h2 className="text-3xl font-extrabold text-[#0f1f3d]">Presencia territorial en Valparaíso</h2>
            <p className="text-slate-500 mt-2">Toca cualquier comuna para ver su coordinador comunal, militantes y simpatizantes.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Lista de comunas */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="todas" className="w-full">
                <div className="flex justify-center mb-4">
                  <TabsList className="bg-slate-200 p-1">
                    <TabsTrigger value="todas" className="px-4 py-2 font-semibold data-[state=active]:bg-[#0f1f3d] data-[state=active]:text-white">Todas</TabsTrigger>
                    <TabsTrigger value="d6" className="px-4 py-2 font-semibold data-[state=active]:bg-[#0f1f3d] data-[state=active]:text-white">Distrito 6</TabsTrigger>
                    <TabsTrigger value="d7" className="px-4 py-2 font-semibold data-[state=active]:bg-[#0f1f3d] data-[state=active]:text-white">Distrito 7</TabsTrigger>
                  </TabsList>
                </div>

                {['todas', 'd6', 'd7'].map((tab) => (
                  <TabsContent key={tab} value={tab}>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {comunas
                        .filter(c => tab === 'todas' || c.d.toLowerCase() === tab)
                        .map((comuna) => (
                          <button
                            key={comuna.name}
                            onClick={() => setSelectedComuna(comuna.name)}
                            className={`text-left p-4 rounded-xl border transition-all hover:shadow-md ${
                              selectedComuna === comuna.name
                                ? 'border-amber-500 bg-amber-50 shadow-md'
                                : 'border-slate-200 bg-white hover:border-amber-300'
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <MapPin className={`w-5 h-5 ${selectedComuna === comuna.name ? 'text-amber-600' : 'text-slate-400'}`} />
                                <span className="font-semibold text-[#0f1f3d]">{comuna.name}</span>
                              </div>
                              <Badge variant="outline" className="text-xs">{comuna.d}</Badge>
                            </div>
                            <div className="flex gap-4 mt-2 ml-8 text-sm text-slate-500">
                              <span>{comuna.militantes} militantes</span>
                              <span>{comuna.simp} simp.</span>
                            </div>
                          </button>
                        ))}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>
            </div>

            {/* Detalle comuna */}
            <div>
              <Card className="border border-slate-200 sticky top-24">
                <CardContent className="p-6">
                  {selected ? (
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <MapPin className="w-5 h-5 text-amber-600" />
                        <h3 className="text-xl font-bold text-[#0f1f3d]">{selected.name}</h3>
                        <Badge variant="outline" className="text-xs">{selected.d}</Badge>
                      </div>
                      <div className="space-y-4">
                        <div className="bg-slate-50 rounded-lg p-4">
                          <p className="text-xs text-slate-500 mb-1">Coordinador/a</p>
                          <p className="font-semibold text-[#0f1f3d]">{selected.coord}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="bg-blue-50 rounded-lg p-4 text-center">
                            <p className="text-2xl font-bold text-blue-600">{selected.militantes.toLocaleString()}</p>
                            <p className="text-xs text-blue-500 mt-1">Militantes</p>
                          </div>
                          <div className="bg-amber-50 rounded-lg p-4 text-center">
                            <p className="text-2xl font-bold text-amber-600">{selected.simp}</p>
                            <p className="text-xs text-amber-500 mt-1">Simpatizantes</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                      <p className="text-slate-500">Haz clic en una comuna para ver detalles.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Ranking */}
      <section className="py-16 bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-extrabold text-[#0f1f3d] mb-8 text-center">Ranking de participación por comuna</h2>
          <div className="space-y-3">
            {[...comunas].sort((a, b) => b.militantes - a.militantes).map((comuna, i) => (
              <div key={comuna.name} className="flex items-center gap-4">
                <span className="w-6 text-center font-bold text-slate-400">{i + 1}</span>
                <span className="w-32 font-medium text-[#0f1f3d] text-sm">{comuna.name}</span>
                <div className="flex-1 bg-slate-100 rounded-full h-6 overflow-hidden relative">
                  <div
                    className="h-full bg-gradient-to-r from-[#0f1f3d] to-amber-500 rounded-full transition-all duration-500"
                    style={{ width: `${(comuna.militantes / 1580) * 100}%` }}
                  />
                </div>
                <span className="w-16 text-right font-semibold text-sm text-[#0f1f3d]">{comuna.militantes.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Transparencia;
