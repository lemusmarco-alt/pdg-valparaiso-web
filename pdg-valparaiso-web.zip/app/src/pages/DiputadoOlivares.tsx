import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, MessageCircle, Home, GraduationCap, Briefcase, HeartPulse } from 'lucide-react';
import { Link } from 'react-router-dom';

const pilares = [
  { icon: Home, title: 'Vivienda Digna', desc: 'Plan regional de vivienda accesible con subsidios especiales para familias del Distrito 6.' },
  { icon: GraduationCap, title: 'Educación de Calidad', desc: 'Fortalecimiento de la educación pública y técnico-profesional en Quilpué, Villa Alemana y San Antonio.' },
  { icon: Briefcase, title: 'Empleo Local', desc: 'Incentivos a pymes locales y programas de capacitación para jóvenes y mujeres.' },
  { icon: HeartPulse, title: 'Salud Cercana', desc: 'Nuevos CESFAM y mejora del acceso a especialistas en comunas periféricas.' },
];

const DiputadoOlivares = () => {
  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-[#0a1628] via-[#0f1f3d] to-[#162a50] py-16 lg:py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <Badge variant="outline" className="mb-4 border-amber-500/50 text-amber-400 bg-amber-500/10 px-4 py-1 text-xs font-semibold">
                DIPUTADO · DISTRITO 6
              </Badge>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white mb-4">
                Javier <span className="text-amber-400">Olivares</span>
              </h1>
              <blockquote className="text-lg sm:text-xl text-slate-300 italic mb-6 leading-relaxed border-l-4 border-amber-500 pl-4">
                "Valparaíso merece un representante que escuche y actúe. Mi compromiso es con cada familia del Distrito 6."
              </blockquote>

              <div className="prose prose-invert max-w-none mb-8">
                <p className="text-slate-300 leading-relaxed">
                  Periodista titulado de la Universidad de Artes, Ciencias y Comunicación (UNIACC) en 2010. Inició su trayectoria en medios de comunicación a los 12 años en Radio San Marcos, y a los 16 se incorporó a Radio FM Hit. En 2007 se integró a Radio Carolina (99.3 FM), donde permaneció hasta 2018.
                </p>
                <p className="text-slate-300 leading-relaxed mt-4">
                  Desarrolló una destacada carrera en televisión: participó como notero en Extra Jóvenes de Chilevisión, conductor de Tremendo Choque, locutor institucional para Jetix Latinoamérica y presentador en Discovery Communications, ShowBiz LA y Mega. Desde 2015 trabajó como corresponsal en medios internacionales en Estados Unidos, incluyendo Telemundo 51, NBC News, Univisión, Al Jazeera Turk y Canal 13 de Chile (Teletrece). Actualmente ejerce como presentador de noticias en Estrella Media (EstrellaTV), con sede en Miami, Florida.
                </p>
                <p className="text-slate-300 leading-relaxed mt-4">
                  Militante del Partido de la Gente. En las elecciones parlamentarias de 2025 fue electo diputado por el Distrito N°6, Región de Valparaíso (comunas de Cabildo, Calle Larga, Catemu, Hijuelas, La Calera, La Cruz, La Ligua, Limache, Llaillay, Los Andes, Nogales, Olmué, Panquehue, Papudo, Petorca, Puchuncaví, Putaendo, Quillota, Quilpué, Quintero, Rinconada, San Esteban, San Felipe, Santa María, Villa Alemana, Zapallar), en representación del Partido de la Gente dentro del pacto del mismo nombre. De acuerdo a la sentencia del Tribunal Calificador de Elecciones (TRICEL), obtuvo <strong className="text-amber-400">32.334 votos</strong>.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <Link to="/voluntarios">
                  <Button className="bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-bold shadow-lg">
                    Súmate a la campaña
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                <a href="https://wa.me/56912345678?text=Hola%20Javier%20Olivares,%20soy%20del%20Distrito%206" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Escribir por WhatsApp
                  </Button>
                </a>
              </div>
            </div>

            <div className="order-1 lg:order-2 flex flex-col items-center">
              <div className="relative">
                <div className="w-72 h-96 sm:w-80 sm:h-[28rem] rounded-3xl overflow-hidden shadow-2xl border-4 border-white/10">
                  <img src="/olivares.jpg" alt="Javier Olivares" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-xl p-4">
                  <p className="text-3xl font-extrabold text-[#0f1f3d]">D6</p>
                  <p className="text-xs text-slate-500">Distrito Sur</p>
                  <p className="text-xs text-slate-500">Valparaíso</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Plan Legislativo */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-3">Plan Legislativo</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0f1f3d]">
              4 ejes para el Distrito 6
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {pilares.map(({ icon: Icon, title, desc }) => (
              <Card key={title} className="border border-slate-200 hover:border-amber-300 hover:shadow-lg transition-all group">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-[#0f1f3d] flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-500 transition-colors">
                    <Icon className="w-7 h-7 text-amber-400 group-hover:text-[#0f1f3d] transition-colors" />
                  </div>
                  <h3 className="font-bold text-[#0f1f3d] text-lg mb-2">{title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">{desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default DiputadoOlivares;
