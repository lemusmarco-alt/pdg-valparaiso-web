import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowRight, MessageCircle, Fish, TreePine, Users, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

const pilares = [
  { icon: Fish, title: 'Economía del Mar', desc: 'Protección a pescadores artesanales y desarrollo del turismo costero sustentable en Valparaíso, Viña del Mar y Concón.' },
  { icon: TreePine, title: 'Medio Ambiente', desc: 'Plan anti-incendios y restauración de zonas afectadas. Protección del patrimonio natural de la región.' },
  { icon: Users, title: 'Adulto Mayor', desc: 'Red regional de cuidados, centros de día y pensión digna para quienes construyeron nuestra región.' },
  { icon: Shield, title: 'Seguridad Ciudadana', desc: 'Más patrullajes, cámaras de vigilancia inteligentes y apoyo a comités vecinales de seguridad.' },
];

const DiputadoValenzuela = () => {
  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-[#0a1628] via-[#0f1f3d] to-[#162a50] py-16 lg:py-24 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <Badge variant="outline" className="mb-4 border-amber-500/50 text-amber-400 bg-amber-500/10 px-4 py-1 text-xs font-semibold">
                DIPUTADO · DISTRITO 7
              </Badge>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white mb-4">
                Juan Marcelo <span className="text-amber-400">Valenzuela</span>
              </h1>
              <blockquote className="text-lg sm:text-xl text-slate-300 italic mb-6 leading-relaxed border-l-4 border-amber-500 pl-4">
                "El Distrito 7 tiene alma de mar y de cerro. Mi compromiso es cuidar lo nuestro y abrir oportunidades."
              </blockquote>

              <div className="prose prose-invert max-w-none mb-8">
                <p className="text-slate-300 leading-relaxed">
                  Cursó la enseñanza básica en el Colegio Arturo Edwards de Valparaíso y la enseñanza media en el Liceo Bicentenario Marítimo B-29 de la misma ciudad. Posteriormente, ingresó a estudiar Ingeniería Comercial en la Universidad de Valparaíso. Tiene estudios de Publicidad.
                </p>
                <p className="text-slate-300 leading-relaxed mt-4">
                  Ejerció su profesión en el ámbito privado como gerente comercial y de comunicaciones de la empresa de asesoría previsional "Felices y Forrados". Entre 2012 y 2019 fue propietario y director principal de la agencia de comunicación estratégica "Ponder", con sede en Viña del Mar, dedicada a la asesoría en marketing político. Fundó el diario digital Granvalparaiso.cl. Ha colaborado como columnista en temas de comunicación política y panelista en Radio Futuro. Desde 2021 integra el panel del programa Bad Boys, conducido junto a Giancarlo Barbagelata, Pedro Gubernatti y Franco Parisi.
                </p>
                <p className="text-slate-300 leading-relaxed mt-4">
                  Miembro fundador y militante del Partido de la Gente (PDG), colectividad política constituida en 2019, en la cual participó activamente en su etapa de conformación inicial.
                </p>
                <p className="text-slate-300 leading-relaxed mt-4">
                  En las elecciones parlamentarias de 2021 se presentó como candidato a diputado por el 7° Distrito, obteniendo 7.217 votos (2,02%). En las elecciones municipales de octubre de 2024 postuló a la alcaldía de Valparaíso, obteniendo 31.036 votos (17,32%). En las elecciones parlamentarias de 2025 fue electo diputado por el 7° Distrito, Región de Valparaíso (comunas de Algarrobo, Cartagena, Casablanca, Concón, El Quisco, El Tabo, Isla de Pascua, Juan Fernández, San Antonio, Santo Domingo, Valparaíso, Viña del Mar), en representación del Partido de la Gente dentro del pacto del mismo nombre. De acuerdo a la sentencia del Tribunal Calificador de Elecciones (TRICEL), obtuvo <strong className="text-amber-400">26.410 votos</strong>.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <Link to="/voluntarios">
                  <Button className="bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-bold shadow-lg">
                    Súmate a la campaña
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                <a href="https://wa.me/56912345678?text=Hola%20Juan%20Marcelo%20Valenzuela" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="border-white/30 text-white hover:bg-white/10">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Escribir por WhatsApp
                  </Button>
                </a>
              </div>
            </div>

            <div className="order-1 lg:order-2 flex flex-col items-center">
              <div className="relative">
                <div className="w-72 h-96 sm:w-80 sm:h-[28rem] rounded-3xl overflow-hidden shadow-2xl border-4 border-white/10">
                  <img src="/valenzuela.jpg" alt="Juan Marcelo Valenzuela" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-xl p-4">
                  <p className="text-3xl font-extrabold text-[#0f1f3d]">D7</p>
                  <p className="text-xs text-slate-500">Distrito Norte</p>
                  <p className="text-xs text-slate-500">Valparaíso</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Plan Legislativo */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-amber-600 font-semibold text-sm uppercase tracking-wider mb-3">Plan Legislativo</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0f1f3d]">
              4 ejes para el Distrito 7
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {pilares.map(({ icon: Icon, title, desc }) => (
              <Card key={title} className="border border-slate-200 hover:border-amber-300 hover:shadow-lg transition-all group">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-[#0f1f3d] flex items-center justify-center mx-auto mb-4 group-hover:bg-amber-500 transition-colors">
                    <Icon className="w-7 h-7 text-amber-400 group-hover:text-[#0f1f3d] transition-colors" />
                  </div>
                  <h3 className="font-bold text-[#0f1f3d] text-lg mb-2">{title}</h3>
                  <p className="text-slate-500 text-sm leading-relaxed">{desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default DiputadoValenzuela;
