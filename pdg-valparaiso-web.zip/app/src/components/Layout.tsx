import { Outlet, useLocation, Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Footer from './Footer';
import { Menu, LogIn } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';

const Layout = () => {
  const { pathname } = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
    setMobileOpen(false);
  }, [pathname]);

  const navItems = [
    { label: 'Inicio', path: '/' },
    { label: 'Dip. Olivares', path: '/olivares' },
    { label: 'Dip. Valenzuela', path: '/valenzuela' },
    { label: 'Transparencia', path: '/transparencia' },
    { label: 'Formación', path: '/formacion' },
    { label: 'Voluntarios', path: '/voluntarios' },
    { label: 'Comunidad', path: '/comunidad' },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#0f1f3d] to-[#1d3560] flex items-center justify-center shadow-md">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-amber-400">
                  <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"/>
                </svg>
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-bold text-[#0f1f3d] leading-tight group-hover:text-[#1d3560] transition-colors">PDG Regional</p>
                <p className="text-xs text-slate-500 leading-tight">Valparaíso</p>
              </div>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    pathname === item.path
                      ? 'bg-[#0f1f3d] text-white shadow-md'
                      : 'text-slate-600 hover:text-[#0f1f3d] hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>

            {/* Right side */}
            <div className="flex items-center gap-2">
              <Button
                className="hidden sm:flex bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-semibold text-sm shadow-md hover:shadow-lg transition-all"
                size="sm"
              >
                <LogIn className="w-4 h-4 mr-1.5" />
                Ingresar
              </Button>

              {/* Mobile menu */}
              <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
                <SheetTrigger asChild className="lg:hidden">
                  <Button variant="ghost" size="icon" className="text-[#0f1f3d]">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-72 bg-white">
                  <div className="flex flex-col gap-1 mt-6">
                    {navItems.map((item) => (
                      <Link
                        key={item.path}
                        to={item.path}
                        onClick={() => setMobileOpen(false)}
                        className={`px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                          pathname === item.path
                            ? 'bg-[#0f1f3d] text-white'
                            : 'text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        {item.label}
                      </Link>
                    ))}
                    <Button className="mt-4 bg-amber-500 hover:bg-amber-600 text-[#0f1f3d] font-semibold w-full">
                      <LogIn className="w-4 h-4 mr-2" />
                      Ingresar
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1">
        <Outlet />
      </main>

      <Footer />
    </div>
  );
};

export default Layout;
