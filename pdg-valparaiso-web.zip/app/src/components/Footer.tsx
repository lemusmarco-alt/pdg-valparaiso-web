import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, Facebook, Instagram, Twitter, Youtube, ArrowUpRight } from 'lucide-react';

const Footer = () => {
  const navLinks = [
    { label: 'Inicio', path: '/' },
    { label: 'Diputado Olivares', path: '/olivares' },
    { label: 'Diputado Valenzuela', path: '/valenzuela' },
    { label: 'Transparencia', path: '/transparencia' },
    { label: 'Ser voluntario', path: '/voluntarios' },
    { label: 'Comunidad', path: '/comunidad' },
  ];

  return (
    <footer className="bg-[#0a1628] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0f1f3d] to-[#1d3560] flex items-center justify-center border border-amber-500/30">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" className="text-amber-400">
                  <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="currentColor"/>
                </svg>
              </div>
              <div>
                <p className="font-bold text-white leading-tight">PDG Regional</p>
                <p className="text-sm text-slate-400 leading-tight">Valparaíso</p>
              </div>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Partido de la Gente — Región de Valparaíso. Construyendo comunidad, transparencia y futuro.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-semibold text-sm uppercase tracking-wider text-slate-300 mb-4">Navegación</h4>
            <ul className="space-y-2.5">
              {navLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-sm text-slate-400 hover:text-amber-400 transition-colors flex items-center gap-1 group"
                  >
                    {link.label}
                    <ArrowUpRight className="w-3 h-3 opacity-0 -translate-y-1 translate-x-1 group-hover:opacity-100 group-hover:translate-y-0 group-hover:translate-x-0 transition-all" />
                  </Link>
                </li>
              ))}
              <li>
                <Link
                  to="#"
                  className="text-sm text-amber-500 hover:text-amber-400 transition-colors flex items-center gap-1"
                >
                  <span className="text-xs">🔒</span> Intranet (directiva)
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold text-sm uppercase tracking-wider text-slate-300 mb-4">Contacto</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5 text-sm text-slate-400">
                <MapPin className="w-4 h-4 mt-0.5 text-amber-500 flex-shrink-0" />
                Av. Pedro Montt 1500, Valparaíso, Chile
              </li>
              <li className="flex items-center gap-2.5 text-sm text-slate-400">
                <Phone className="w-4 h-4 text-amber-500 flex-shrink-0" />
                +56 32 222 3344
              </li>
              <li className="flex items-center gap-2.5 text-sm text-slate-400">
                <Mail className="w-4 h-4 text-amber-500 flex-shrink-0" />
                contacto@pdgvalparaiso.cl
              </li>
            </ul>
          </div>

          {/* Social */}
          <div>
            <h4 className="font-semibold text-sm uppercase tracking-wider text-slate-300 mb-4">Síguenos</h4>
            <div className="flex items-center gap-3 mb-4">
              <a href="https://www.facebook.com/pdgchile" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-500 hover:text-[#0f1f3d] transition-all text-slate-400">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="https://www.instagram.com/pdelagentechile" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-500 hover:text-[#0f1f3d] transition-all text-slate-400">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://x.com/ChilePDGcl" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-500 hover:text-[#0f1f3d] transition-all text-slate-400">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="https://www.youtube.com/@partidodelagentechile8345" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-amber-500 hover:text-[#0f1f3d] transition-all text-slate-400">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
            <p className="text-sm text-slate-500">
              Únete a nuestra red. Recibe las últimas novedades de la campaña directo en tu correo.
            </p>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-slate-500">
            © 2026 PDG Regional Valparaíso. Todos los derechos reservados.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="text-sm text-slate-500 hover:text-slate-300 transition-colors">Política de privacidad</a>
            <a href="#" className="text-sm text-slate-500 hover:text-slate-300 transition-colors">Términos de uso</a>
            <Link to="#" className="text-sm text-amber-500 hover:text-amber-400 transition-colors flex items-center gap-1">
              <span className="text-xs">🔒</span> Intranet
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
